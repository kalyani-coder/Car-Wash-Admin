// MockApi.js

const MockApi = [
  {
    id: 1,
    name: "John Doe",
    address: {
      street: "123 Main St",
      suite: "Apt 4B",
      city: "New York",
      zipcode: "10001",
    },
    orderDetails:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed varius, purus eu aliquam dictum.",
  },
  {
    id: 3,
    name: "Jane Smith",
    address: {
      street: "456 Elm St",
      suite: "Unit 7",
      city: "Los Angeles",
      zipcode: "90001",
    },
    orderDetails:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed varius, purus eu aliquam dictum.",
  },
  {
    id: 4,
    name: "Amar",
    address: {
      street: "456 Elm St",
      suite: "Unit 7",
      city: "Los Angeles",
      zipcode: "90001",
    },
    orderDetails:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed varius, purus eu aliquam dictum.",
  },
  {
    id: 5,
    name: "vedant",
    address: {
      street: "456 Elm St",
      suite: "Unit 7",
      city: "Los Angeles",
      zipcode: "90001",
    },
    orderDetails:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed varius, purus eu aliquam dictum.",
  },
  {
    id: 6,
    name: "ajay",
    address: {
      street: "456 Elm St",
      suite: "Unit 7",
      city: "Los Angeles",
      zipcode: "90001",
    },
    orderDetails:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed varius, purus eu aliquam dictum.",
  },
  {
    id: 7,
    name: "soham",
    address: {
      street: "456 Elm St",
      suite: "Unit 7",
      city: "Los Angeles",
      zipcode: "90001",
    },
    orderDetails:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed varius, purus eu aliquam dictum.",
  },
  {
    id: 8,
    name: "Vivek",
    address: {
      street: "456 Elm St",
      suite: "Unit 7",
      city: "Los Angeles",
      zipcode: "90001",
    },
    orderDetails:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed varius, purus eu aliquam dictum.",
  },
  {
    id: 9,
    name: "Jane Smith",
    address: {
      street: "456 Elm St",
      suite: "Unit 7",
      city: "Los Angeles",
      zipcode: "90001",
    },
    orderDetails:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed varius, purus eu aliquam dictum.",
  },
  {
    id: 10,
    name: "nikhil",
    address: {
      street: "456 Elm St",
      suite: "Unit 7",
      city: "Los Angeles",
      zipcode: "90001",
    },
    orderDetails:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed varius, purus eu aliquam dictum.",
  },
  // Add more customer data entries as needed
];

export default MockApi;
